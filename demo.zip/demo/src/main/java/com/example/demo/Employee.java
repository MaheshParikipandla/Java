package com.example.demo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Employee
{
    @Id
    @GeneratedValue
    private Long id;
    private String firstname;
    private String lastname;

    public Employee(String firstname, String lastname)
    {
        this.firstname = firstname;
        this.lastname = lastname;
    }
    public Employee()
    {

    }
    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }


    public void setId(Long id)
    {
        this.id=id;
    }
    public Long getId(Long id)
    {
        return id;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "id=" + id +
                ", firstname='" + firstname + '\'' +
                ", lastname='" + lastname + '\'' +
                '}';
    }
}
