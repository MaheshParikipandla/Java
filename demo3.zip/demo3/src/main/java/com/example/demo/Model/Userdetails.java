package com.example.demo.Model;


import javax.persistence.*;

@Entity
@Table(name = "Users")
public class Userdetails {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public int id;

    @Column(name = "username")
    public String username;

    @Column(name = "Email")
    public String Email;

    @Column(name = "password")
    public String password;

    public Userdetails() {
    }

    public Userdetails(int id, String username,String Email, String password) {
        this.id = id;
        this.username = username;
        this.Email=Email;
        this.password = password;
    }
    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}

