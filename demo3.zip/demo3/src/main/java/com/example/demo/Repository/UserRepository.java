package com.example.demo.Repository;

import com.example.demo.Model.Userdetails;
import org.springframework.data.jpa.repository.JpaRepository;


public interface UserRepository extends JpaRepository<Userdetails,Long> {
}
