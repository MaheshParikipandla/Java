package com.example.demo.Controller;

import com.example.demo.Model.UserModel;
import com.example.demo.Model.Userdetails;
import com.example.demo.Repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import java.sql.SQLException;

@Controller
public class Controllers {

    @Autowired
    UserModel userModel;

    @Autowired
    private UserRepository userRepository;

    @GetMapping("/index")
    public String index(){
        return "index";
    }
    @GetMapping("/product")
    public String product(){
        return "product";
    }
    @GetMapping("/Acc")
    public String account(){
        return "Acc";
    }
    @GetMapping("/cart")
    public String cart(){
        return "cart";
    }
    @GetMapping("/product_details")
    public String details(){
        return "product_details";
    }
    @GetMapping("/success")
    public String success(){
        return "success";
    }
    @GetMapping("/welcome")
    public String welcome(){
        return "welcome";
    }


    @RequestMapping("/save")
    public String save(@ModelAttribute("Users") Userdetails userdetails) throws ClassNotFoundException, SQLException {
        System.out.println(userdetails.id);
        System.out.println(userdetails.username);
        System.out.println(userdetails.Email);
        System.out.println(userdetails.password);
        userModel.insert(userdetails);
        return "Acc";
    }
    @GetMapping("/login")
    public String login(@ModelAttribute("Users") Userdetails userdetails)throws ClassNotFoundException, SQLException {
        return "login";
    }
    @GetMapping("/error")
    public String error(){
        return "error";
    }
    @GetMapping("/logout")
    public String logout(){
        return "logout";
    }
}

